#include <stdio.h>
#include <stdlib.h>
#include "datatypes.h"

array2d_t *array2d_alloc(const size_t shape[2], enum storage_order order);
array2d_t *array2d_from_file(const char *filename);
void array2d_fprint(FILE *stream, const array2d_t *a);

int main(void)
{
    array2d_t *a = array2d_from_file("./msptools/data/A1.txt");
    array2d_t *b = array2d_from_file("./msptools/data/v1.txt");

    array2d_fprint(stdout, a);
    array2d_fprint(stdout, b);

    return 0;
}